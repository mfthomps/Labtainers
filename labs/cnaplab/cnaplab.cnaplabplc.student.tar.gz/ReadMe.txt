Release Notes:

----------------------------------
User Downloaded Webpages and Files
----------------------------------

This is the user download web directory.

Enable the FTP service to upload/download files here.

To view these files with a browser you must specify the path "/user/web/" in the URL.

For example: 
This file is named ReadMe.txt.

To read this file with a web browser use the appropriate URL for your device, such as:

http://<Replace with the EWEB IP or Hostname>/user/web/ReadMe.txt

-----------------
Default Home Page
-----------------

If you configure a custom homepage you can return to the EWEB built-in pages by typing:

http://<Replace with the EWEB IP or Hostname>/index.html

