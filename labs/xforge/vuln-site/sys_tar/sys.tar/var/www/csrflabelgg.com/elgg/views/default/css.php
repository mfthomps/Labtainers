<?php
/**
 *
 * This is a deprecated CSS view used in Elgg 1.0-1.7.
 * Please use the view 'css/elgg' now.
 *
 */
