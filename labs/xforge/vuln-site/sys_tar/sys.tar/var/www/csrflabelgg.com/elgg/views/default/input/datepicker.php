<?php
/**
 * @deprecated use input/date instead
 */
elgg_deprecated_notice('input/datepicker was deprecated in favor of input/date', 1.8);
echo elgg_view('input/date', $vars);