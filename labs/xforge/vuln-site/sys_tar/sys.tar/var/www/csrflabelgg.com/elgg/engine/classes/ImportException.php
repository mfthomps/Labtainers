<?php
/**
 * Import exception
 *
 * @package    Elgg.Core
 * @subpackage Exception
 */
class ImportException extends DataFormatException {}
