/**
 * CSS for IE6
 */

* {zoom: 1;} /* trigger hasLayout in IE */

/* main nav drop-down */
#elgg-header {z-index:1;}

/* @todo check this one */
.elgg-button-delete a { background-position-y: 2px; }
.elgg-button-delete a:hover { background-position-y: -14px; }