<?php
/**
 * NotImplementedException
 * Thrown when a method or function has not been implemented, primarily used
 * in development... you should not see these!
 *
 * @package    Elgg.Core
 * @subpackage Exception
 */
class NotImplementedException extends CallException {}
