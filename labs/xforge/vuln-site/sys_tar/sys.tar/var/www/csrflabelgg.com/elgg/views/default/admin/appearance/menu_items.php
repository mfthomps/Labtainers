<?php
/**
 * Elgg administration menu items
 *
 * @package Elgg
 * @subpackage Core
 */


echo elgg_view_form('admin/menu/save', array('class' => 'elgg-form-settings'));
