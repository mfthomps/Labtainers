<?php
/**
 * Elgg administration site advanced settings
 *
 * @package Elgg
 * @subpackage Core
 */

echo elgg_view_form('admin/site/update_advanced', array('class' => 'elgg-form-settings'));
