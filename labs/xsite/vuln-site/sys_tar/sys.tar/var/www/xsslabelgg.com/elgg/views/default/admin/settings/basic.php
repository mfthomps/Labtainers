<?php
/**
 * Elgg administration site basic settings
 *
 * @package Elgg
 * @subpackage Core
 */

echo elgg_view_form('admin/site/update_basic', array('class' => 'elgg-form-settings'));
