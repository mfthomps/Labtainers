<?php
/**
 * Elgg XML output for XML-RPC
 *
 * @package Elgg
 * @subpackage Core
 */

$result = $vars['result'];

echo "$result";