<?php
/**
 * Elgg list view switcher
 *
 * @package Elgg
 * @subpackage Core
 * 
 * @deprecated 1.8 See how file plugin adds a toggle in function file_register_toggle()
 */

elgg_deprecated_notice('navigation/viewtype was deprecated', 1.8);
